from pathlib import Path
import json
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
from reportlab.pdfgen import canvas
from reportlab.lib.colors import HexColor, white
from reportlab.lib.styles import ParagraphStyle
from reportlab.platypus import Paragraph, Table, TableStyle
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont

ROOT=Path(__file__).resolve().parent.parent
OUT=ROOT/'report'
OUT.mkdir(exist_ok=True)
FONT='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
BOLD='/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'
pdfmetrics.registerFont(TTFont('Body',FONT))
pdfmetrics.registerFont(TTFont('Bold',BOLD))
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,
                    'axes.spines.right':False,'axes.labelcolor':'#26352f','text.color':'#26352f'})
fig,axs=plt.subplots(1,2,figsize=(9,3.1),gridspec_kw={'wspace':0.45})
labels=['Thick A','Thin-short B','Thin-long C']
colors=['#28634b','#a1ba97','#d3ded0']
axs[0].bar(labels,[2.3153915188,8.0508705053,6.4431673064],color=colors,width=.62)
axs[0].set_ylabel('Diagnostic reads per million')
axs[0].set_title('GWHPAAAA003778',loc='left',fontweight='bold')
axs[0].set_ylim(0,9.8)
for j,v in enumerate([2.3153915188,8.0508705053,6.4431673064]):axs[0].text(j,v+.18,f'{v:.2f}',ha='center',fontsize=10)
axs[0].text(.02,.98,'Shared flowcell, first 75 bases',transform=axs[0].transAxes,va='top',fontsize=8)
axs[1].bar(labels,[14.355427,28.472591,30.006751],color=colors,width=.62)
axs[1].set_ylim(0,36)
axs[1].set_ylabel('Diagnostic reads per million')
axs[1].set_title('TkBG11 control',loc='left',fontweight='bold')
for j,v in enumerate([14.355,28.473,30.007]):axs[1].text(j,v+.6,f'{v:.2f}',ha='center',fontsize=10)
fig.savefig(OUT/'sequencing_comparison.png',dpi=200,bbox_inches='tight',facecolor='white')
plt.close(fig)

rows=pd.read_csv(ROOT/'model/output/functional_changes.csv')
selected=[0,6,1,7]
fig,ax=plt.subplots(figsize=(9,3.0))
x=np.arange(4)
ax.bar(x-.18,rows.iloc[selected].mass_change_percent,.35,color='#28634b',label='Total root dry-matter equivalent')
ax.bar(x+.18,rows.iloc[selected].inulin_change_percent,.35,color='#c68d44',label='Inulin equivalent')
ax.set_xticks(x,['Baseline','Capacity + allocation','Lower turnover','All three changes'])
ax.set_ylabel('Change from baseline (%)')
ax.axhline(0,color='#777777',linewidth=.6)
ax.set_ylim(-3.5,24)
ax.legend(frameon=False,loc='upper left',fontsize=9)
for j,r in enumerate(rows.iloc[selected].itertuples()):
 for off,val in [(-.18,r.mass_change_percent),(.18,r.inulin_change_percent)]:
  if j>0:ax.text(j+off,val+.4 if val>=0 else val-.7,f'{val:+.1f}',ha='center',va='bottom' if val>=0 else 'top',fontsize=9)
fig.savefig(OUT/'functional_comparison.png',dpi=200,bbox_inches='tight',facecolor='white')
plt.close(fig)

pred=pd.read_csv(ROOT/'model/output/developmental_residuals.csv')
pred=pred[(pred.model=='late_k0')&(pred.endpoint=='inulin_per_root')]
fig,ax=plt.subplots(figsize=(9,3.0))
ax.plot(pred.age_week,pred.prediction,'o--',color='#bd713c',label='Best of nine simple model cases')
ax.scatter([8,12,24],[.075,1.35,2.725],color='#28634b',s=42,zorder=4,label='Approximate published means')
ax.errorbar([12,24],[1.35,2.725],yerr=[.63,.55],fmt='none',color='#28634b',capsize=4)
ax.axvspan(7,13,color='#e9f0e6',alpha=.6,zorder=0)
ax.text(10,3.25,'Ages used for fitting',ha='center',fontsize=9)
ax.text(23.4,3.5,'Later-age check',ha='center',fontsize=9)
ax.set_xticks([8,12,24]);ax.set_xlabel('Age (weeks)');ax.set_ylabel('Inulin per root (g)')
ax.set_ylim(-.1,3.8);ax.legend(frameon=False,loc='upper left',bbox_to_anchor=(.01,.83),fontsize=9)
fig.savefig(OUT/'developmental_check.png',dpi=200,bbox_inches='tight',facecolor='white')
plt.close(fig)

P=OUT/'Dandelions_Integrated_Study_20261124.pdf'
c=canvas.Canvas(str(P),pagesize=(595.28,841.89))
c.setTitle('Dandelions - verified candidate evidence and integrated root model')
c.setAuthor('Phasespace Design Lab')
style=ParagraphStyle('body',fontName='Body',fontSize=10.2,leading=15,textColor=HexColor('#25362d'),spaceAfter=8)
small=ParagraphStyle('small',parent=style,fontSize=8.5,leading=12)
heading=ParagraphStyle('heading',fontName='Bold',fontSize=15,leading=20,textColor=HexColor('#28634b'))

def para(text,y,sty=style):
 p=Paragraph(text,sty);w,h=p.wrap(499,y-50);p.drawOn(c,48,y-h);return y-h-10

def title(number,top,sub):
 c.setFillColor(HexColor('#28634b'));c.rect(0,808,595.28,34,fill=1,stroke=0)
 c.setFont('Bold',10);c.setFillColor(white);c.drawString(48,821,'PHASESPACE DESIGN LAB  /  DANDELIONS 18')
 c.setFont('Bold',22);c.setFillColor(HexColor('#25362d'));c.drawString(48,772,top)
 c.setFont('Body',10);c.drawString(48,749,sub)
 c.setStrokeColor(HexColor('#c9d6ca'));c.line(48,54,547,54)
 c.setFont('Body',8);c.drawString(48,38,'24 November 2026  |  Computational study v01  |  Model 0.2.0')
 c.drawRightString(547,38,f'{number} / 3')
 return 719

y=title(1,'A stronger dandelion candidate','Completed sequencing analysis and a first integrated functional model')
y=para('The immediate aim is to identify changes in the plant that could support larger roots and greater stored inulin. This study completes the original-read check for a glucanase candidate and tests explicit functional changes under a shared resource budget.',y)
c.drawImage(str(OUT/'sequencing_comparison.png'),48,425,width=499,height=210,preserveAspectRatio=True,anchor='c')
y=410
y=para('The candidate signal survives the technical comparison',y,heading)
y=para('GWHPAAAA003778 remains lower in thick-root pool A after restricting reads to the same sequencing flowcell and the first 75 bases. The comparison assigns 5 reads in A, 41 in thin-short B and 35 in thin-long C. Corresponding A/B and A/C abundance ratios are 0.288 and 0.359. TkBG11 provides a published directional control.',y)
y=para('Execution and verification',y,heading)
y=para('All 14,498,640 archived reads were processed. Each file\'s read and base totals match official archive metadata. Diagnostic sequences were checked against 46,734 coding-sequence records. Fifteen synthetic tests passed. A separate Python implementation reproduced all assignments from the 798 retained diagnostic reads.',y)
y=para('The archives carry SUPPRESSED status without a stated reason, and their totals differ from the publication. There is one pooled sample per condition. Sparse counts, coding-sequence coverage and reference variation limit the association. These results establish a reproducible direction in the retrieved files. Causal effects on growth and inulin require biological testing.',y,small)
y=para('Primary study and archive identifiers<br/>Wieghaus et al. (2022), DOI 10.3389/fgene.2021.784883. Root-tip runs SRR17037343, SRR17037341 and SRR17037339. Original metadata, file hashes and detailed methods accompany the report.',y,small)
assert y>60,y
c.showPage()
y=title(2,'What functional uplift would require','Conditional comparisons under the same effective input budget')
y=para('The model extends the recovered two-pool experiment with finite storage capacity, a competing root pool, loss and developmental input profiles. Its mass balance is explicit. Other root material includes structures and compounds beyond inulin. The equations use effective dry-matter equivalents.',y)
c.drawImage(str(OUT/'functional_comparison.png'),48,429,width=499,height=207,preserveAspectRatio=True,anchor='c')
y=414
y=para('More storage can draw on other root material',y,heading)
y=para('The test assumes 25% greater storage capacity, 10% higher requested inulin allocation and 25% lower inulin mobilization. Together these changes produce +1.82% total root mass and +18.04% inulin under the same input budget. The other-root pool falls 15.58%. With capacity and allocation alone, inulin rises 9.30% while root mass falls 1.08%.',y)
y=para('These functional magnitudes were selected for sensitivity testing. Their quantitative mapping to genes, introduced functions or symbioses remains unknown. The current model also leaves whole-plant growth, reproduction and food suitability unresolved.',y)
y=para('A harvest endpoint still permits several mechanisms',y,heading)
y=para('Forty-nine of 81 parameter cases reproduce the same control endpoint while producing different intermediate histories. The largest inulin spread in the selected day-14-to-day-70 grid occurs on day 53. That date depends on the chosen model grid. Independent replay, conservation, capacity and integration-convergence checks passed.',y)
y=para('The 2019 benchmark uses 1.89 g dry mass and 49.9% inulin as representative control targets. Their product is 0.943 g. The study separately reports a 1.08 g mean inulin yield from a different sample set. These values retain separate roles. The additional-supply test scales all states linearly by construction.',y,small)
y=para('Benchmark source<br/>Wieghaus, Pruefer and Schulze Gronover (2019), PLOS ONE, DOI 10.1371/journal.pone.0217454, Tables 2-4. Assumptions, all scenario outputs and the original model are included.',y,small)
assert y>60,y
c.showPage()
y=title(3,'Development exposes a limitation','A completed negative test of the simple growth profiles')
y=para('An independent published time series provides a demanding check. Nine model cases were fitted to approximate control inulin amount and concentration at eight and twelve weeks. All reproduce the early trajectory poorly. The later observation was excluded from fitting.',y)
c.drawImage(str(OUT/'developmental_check.png'),48,425,width=499,height=210,preserveAspectRatio=True,anchor='c')
y=410
y=para('The modeled increase is much too slow',y,heading)
y=para('The best early fit gives 0.187 g inulin at twelve weeks against approximately 1.35 g in the source figure. At twenty-four weeks it gives 0.748 g against approximately 2.725 g. Sixteen perturbations within the graph-reading bounds produce later predictions between 0.432 and 1.081 g. This result identifies inadequacy in the tested developmental profiles and fixed parameters.',y)
y=para('The error bars show published standard deviations at the two later ages. Eight-week data comprise five pools of four plants. Later data comprise six individual plants. Graph-reading uncertainty is recorded separately. Equal relative residuals were used for fitting, and the sensitivity cases have no probability interpretation.',y,small)
y=para('The next biological distinction',y,heading)
y=para('Plant uplift could involve stronger effective input during thickening, greater storage capacity, altered allocation or improved retention. The next discriminating observations are paired root dry mass, inulin amount and composition across that developmental transition. Candidate expression must be paired with individual root measurements and plant performance. The verified gene association helps prioritize the candidate; the failed developmental fit identifies the mechanism that the current model still needs to resolve.',y)
y=para('Primary developmental source<br/>Benninghaus et al. (2020), Journal of Experimental Botany, DOI 10.1093/jxb/erz512, Supplementary Figure S9B. The original supplement and digitized values accompany the report. Code, checksums and execution receipts document the completed computations.',y,small)
assert y>60,y
c.save()
print(P)
