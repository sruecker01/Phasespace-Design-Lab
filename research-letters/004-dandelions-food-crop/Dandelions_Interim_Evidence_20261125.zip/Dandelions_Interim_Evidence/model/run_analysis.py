"""Reproduce the conditional root-allocation experiment and numerical checks."""
from dataclasses import asdict, replace
from itertools import product
from pathlib import Path
import csv
import hashlib
import json
import platform
import time

import numpy as np
from scipy.optimize import least_squares
from scipy.special import expit, logit
from model import Parameters, simulate, VERSION
import legacy_model

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'output'
TARGET_MASS = 1.89
TARGET_FRACTION = 0.499
TARGET_INULIN = TARGET_MASS * TARGET_FRACTION


def write_csv(path, rows):
    with path.open('w', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def fit(template):
    def make(theta):
        return replace(template, budget=float(np.exp(theta[0])),
                       inulin_share=float((1-template.competing_share)*expit(theta[1])))
    def residual(theta):
        y = simulate(make(theta), [template.duration], max_step=2.0, tolerance=1e-8)
        return [(y['dry_mass'][0]-TARGET_MASS)/TARGET_MASS,
                (y['I'][0]-TARGET_INULIN)/TARGET_INULIN]
    optimum = least_squares(residual, [np.log(2.4), logit(0.7)],
                             bounds=([np.log(0.1), -10], [np.log(100), 10]),
                             max_nfev=100, ftol=1e-10, xtol=1e-10, gtol=1e-10)
    params = make(optimum.x)
    y = simulate(params, [params.duration])
    error = max(abs(y['dry_mass'][0]-TARGET_MASS), abs(y['I'][0]-TARGET_INULIN))
    return params, error, optimum.nfev


def endpoint(label, params):
    y = simulate(params)
    return {'scenario': label, 'budget_g_equivalent': params.budget,
            'dry_mass_g_equivalent': y['dry_mass'][-1], 'inulin_g_equivalent': y['I'][-1],
            'inulin_fraction': y['inulin_fraction'][-1], 'other_root_g_equivalent': y['N'][-1],
            'competing_pool_g_equivalent': y['R'][-1], 'loss_g_equivalent': y['L'][-1],
            'mass_ceiling_g_equivalent': params.budget+params.initial_n+params.initial_i+params.initial_r,
            'max_balance_error_g': max(abs(y['residual']))}


def verification(baseline):
    checks = []
    for k, eta in product([0.0, 0.01, 0.05], [0.0, 0.5, 1.0]):
        old = legacy_model.Parameters(0.03, 0.6, k, eta, 0.03, 0.01)
        new = Parameters(budget=0.03*84, inulin_share=0.6, turnover=k, recovery=eta,
                         competing_share=0.15, competing_retention=1,
                         capacity_ratio=float('inf'), supply_profile='constant',
                         initial_n=0.02, initial_i=0.01, initial_r=0.01)
        y = simulate(new, [21,42,84])
        error = max(np.max(np.abs(np.array(legacy_model.state(old,day))-
                    np.array([y['N'][j]+y['R'][j], y['I'][j], y['L'][j]])))
                    for j,day in enumerate([21,42,84]))
        checks.append({'check': f'legacy_k{k}_eta{eta}', 'error': float(error), 'limit': 1e-7})
    zero = simulate(replace(baseline,budget=0))
    checks.append({'check': 'zero_input_zero_initial', 'error': float(max(zero['dry_mass'])), 'limit': 1e-12})
    for cap, alloc in product([0,0.25],[0,0.1]):
        a = replace(baseline, recovery=1, competing_retention=1, capacity_gain=cap,
                    allocation_gain=alloc, capacity_day=28, allocation_day=28)
        y = simulate(a)
        checks.append({'check': f'no_loss_mass_cap{cap}_alloc{alloc}',
                       'error': float(abs(y['dry_mass'][-1]-a.budget)), 'limit': 1e-7})
    for day in (0,28,56):
        a = replace(baseline,capacity_gain=0.25,allocation_gain=0.1,capacity_day=day,allocation_day=day)
        runs = [simulate(a,max_step=step,tolerance=1e-10) for step in (1.0,0.5,0.25)]
        error = max(float(np.max(np.abs(runs[1][key]-runs[2][key]))) for key in ('N','I','R','L'))
        checks.append({'check': f'convergence_day{day}', 'error': error, 'limit': 2e-6})
    for check in checks:
        check['passed'] = bool(check['error'] <= check['limit'])
    if not all(check['passed'] for check in checks):
        raise AssertionError(checks)
    write_csv(OUT/'verification.csv', checks)
    return checks


def main():
    start = time.time()
    OUT.mkdir(exist_ok=True)
    baseline,error,_ = fit(Parameters(budget=2.4,inulin_share=0.6))
    if error > 1e-5:
        raise AssertionError(f'Baseline fit failed {error}')
    (OUT/'baseline_parameters.json').write_text(json.dumps(asdict(baseline),indent=2)+'\n')
    rows = []
    trajectories = []
    all_params = []
    for source, capacity, allocation in product([0,1],repeat=3):
        label = f'supply{source}_capacity{capacity}_allocation{allocation}'
        a = replace(baseline, budget=baseline.budget*(1+0.2*source),
                    capacity_gain=0.25*capacity, allocation_gain=0.1*allocation,
                    capacity_day=28, allocation_day=28)
        all_params.append(a)
        row = endpoint(label,a)
        row.update({'extra_supply':source,'higher_capacity':capacity,'higher_allocation':allocation})
        rows.append(row)
        series=simulate(a)
        for j,day in enumerate(series['day']):
            trajectories.append({'scenario':label, **{key:float(value[j]) for key,value in series.items()}})
    write_csv(OUT/'factorial_endpoints.csv',rows)
    write_csv(OUT/'factorial_trajectories.csv',trajectories)
    interactions = []
    for source in [0,1]:
        subset = {(r['higher_capacity'],r['higher_allocation']):r for r in rows if r['extra_supply']==source}
        for variable in ('dry_mass_g_equivalent','inulin_g_equivalent'):
            interaction = subset[1,1][variable]-subset[1,0][variable]-subset[0,1][variable]+subset[0,0][variable]
            interactions.append({'extra_supply':source,'endpoint':variable,'additive_interaction_g_equivalent':interaction})
    write_csv(OUT/'factorial_interactions.csv',interactions)

    timing=[]
    for day,profile in product([0,28,56],['constant','early','late','hump']):
        a=replace(baseline,capacity_gain=0.25,allocation_gain=0.1,capacity_day=day,allocation_day=day,supply_profile=profile)
        row=endpoint(f'day{day}_{profile}',a)
        row.update({'intervention_day':day,'supply_profile':profile})
        timing.append(row)
    write_csv(OUT/'timing_comparisons.csv',timing)

    fit_rows=[]
    accepted=[]
    for k,eta,capacity,profile in product([0,0.01,0.03],[0,0.5,1],[1.25,1.5,3],['constant','hump','late']):
        template=replace(baseline,turnover=k,recovery=eta,capacity_ratio=capacity,supply_profile=profile)
        a,err,nfev=fit(template)
        row=asdict(a)
        row.update({'endpoint_error_g':err,'optimizer_evaluations':nfev,'matches_targets':err<1e-5})
        fit_rows.append(row)
        if err<1e-5:
            accepted.append(a)
    write_csv(OUT/'endpoint_fits.csv',fit_rows)
    bands=[]
    series=[simulate(a) for a in accepted]
    for j,day in enumerate(series[0]['day']):
        row={'day':day}
        for key in ['I','dry_mass','N','R','L']:
            values=[r[key][j] for r in series]
            row[key+'_min']=min(values)
            row[key+'_max']=max(values)
            row[key+'_range']=max(values)-min(values)
        bands.append(row)
    write_csv(OUT/'endpoint_equivalent_trajectory_ranges.csv',bands)
    intermediate=[r for r in bands if 14<=r['day']<=70]
    best=max(intermediate,key=lambda r:r['I_range'])

    # Stress-test competing-pool retention and capacity response time without refitting.
    stress=[]
    for retention,tau in product([0.4,0.7,1.0],[0.5,2.0,7.0]):
        base=replace(baseline,competing_retention=retention,filling_days=tau)
        local=[]
        for cap,alloc in product([0,1],repeat=2):
            a=replace(base,capacity_gain=.25*cap,allocation_gain=.1*alloc,capacity_day=28,allocation_day=28)
            r=endpoint(f'retention{retention}_tau{tau}_cap{cap}_alloc{alloc}',a)
            r.update({'competing_retention':retention,'filling_days':tau,'higher_capacity':cap,'higher_allocation':alloc})
            local.append(r)
        stress.extend(local)
    write_csv(OUT/'parameter_sensitivity.csv',stress)
    checks=verification(baseline)
    summary={'model_version':VERSION,'baseline_fit_error_g':error,'factorial_runs':len(rows),
             'timing_runs':len(timing),'endpoint_fit_attempts':len(fit_rows),'endpoint_fits_accepted':len(accepted),
             'sensitivity_runs':len(stress),'verification_checks':len(checks),'all_verification_passed':True,
             'most_separating_intermediate_day_for_I_in_grid':float(best['day']),
             'intermediate_I_range_g_equivalent':float(best['I_range']),
             'calibration_target':{'mass':TARGET_MASS,'fraction':TARGET_FRACTION,'proxy_inulin':TARGET_INULIN,
              'reported_yield_held_separate':1.08},
             'interpretation':'Conditional accounting experiment; grid ranges are selected stress cases, not probabilities. No fitted gene-to-parameter relation.',
             'runtime_seconds':time.time()-start,'python':platform.python_version()}
    (OUT/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    print(json.dumps(summary,indent=2))

if __name__=='__main__':
    main()
