"""Root dry-matter-equivalent allocation model, version 0.2.0.

N is retained root material excluding inulin and a competing pool R.
All state and flux units retain the inherited model's effective dry-matter
convention, after unmodelled upstream conversion. N is not measured cell mass.
"""
from dataclasses import dataclass, replace
import math
import numpy as np
from scipy.integrate import solve_ivp

VERSION = '0.2.0'

@dataclass(frozen=True)
class Parameters:
    budget: float
    inulin_share: float
    turnover: float = 0.01
    recovery: float = 0.5
    competing_share: float = 0.05
    competing_retention: float = 0.7
    capacity_ratio: float = 1.5
    filling_days: float = 2.0
    duration: float = 84.0
    supply_profile: str = 'hump'
    initial_n: float = 0.0
    initial_i: float = 0.0
    initial_r: float = 0.0
    capacity_gain: float = 0.0
    capacity_day: float = 0.0
    allocation_gain: float = 0.0
    allocation_day: float = 0.0

    def __post_init__(self):
        numeric = [value for key, value in vars(self).items()
                   if key not in ('supply_profile', 'capacity_ratio')]
        if not all(math.isfinite(value) for value in numeric):
            raise ValueError('Model inputs must be finite')
        if min(self.budget, self.turnover, self.initial_n, self.initial_i,
               self.initial_r, self.capacity_gain, self.allocation_gain) < 0:
            raise ValueError('Negative rate, mass or intervention gain')
        if min(self.duration, self.filling_days, self.capacity_ratio) <= 0:
            raise ValueError('Duration, filling time and capacity must be positive')
        if math.isnan(self.capacity_ratio):
            raise ValueError('Capacity is NaN')
        if not all(0 <= x <= 1 for x in (self.recovery, self.competing_share,
                                         self.competing_retention, self.inulin_share)):
            raise ValueError('Fraction outside [0,1]')
        if self.inulin_share * (1+self.allocation_gain) + self.competing_share > 1+1e-12:
            raise ValueError('Requested allocations exceed the common supply')
        if self.supply_profile not in ('constant', 'early', 'late', 'hump'):
            raise ValueError('Unknown supply profile')
        if min(self.capacity_day, self.allocation_day) < 0:
            raise ValueError('Activation precedes model start')
        initial_capacity = self.capacity_ratio * self.initial_n
        if self.capacity_day == 0:
            initial_capacity *= 1+self.capacity_gain
        if math.isfinite(self.capacity_ratio) and self.initial_i > initial_capacity+1e-12:
            raise ValueError('Initial inulin exceeds available capacity')


def supply_rate(a, day):
    x = max(0.0, min(day/a.duration, 1.0))
    shapes = {'constant': 1.0, 'early': 2*(1-x), 'late': 2*x, 'hump': 6*x*(1-x)}
    return a.budget / a.duration * shapes[a.supply_profile]


def supplied(a, day):
    x = max(0.0, min(day/a.duration, 1.0))
    integrals = {'constant': x, 'early': 2*x-x*x, 'late': x*x, 'hump': 3*x*x-2*x*x*x}
    return a.budget * integrals[a.supply_profile]


def derivative(a, day, state):
    n, i, r, loss = state
    incoming = supply_rate(a, day)
    share = a.inulin_share * (1+a.allocation_gain)
    request_i = share * incoming
    if math.isfinite(a.capacity_ratio):
        capacity = a.capacity_ratio * (1+a.capacity_gain) * n
        available_rate = max(capacity-i, 0.0) / a.filling_days
        request_i = min(request_i, available_rate)
    competing = a.competing_share * incoming
    mobilized = a.turnover * i
    return (incoming-request_i-competing+a.recovery*mobilized,
            request_i-mobilized,
            a.competing_retention*competing,
            (1-a.recovery)*mobilized+(1-a.competing_retention)*competing)


def simulate(a, times=None, max_step=0.5, tolerance=1e-9):
    """Integrate each activation interval independently; all boundary states are continuous."""
    times = np.append(np.arange(0, a.duration, 1.0), a.duration) if times is None else np.array(times, dtype=float)
    if times.ndim != 1 or times.size == 0 or not np.all(np.isfinite(times)):
        raise ValueError('Observation times must be a finite vector')
    if np.any(times < 0) or np.any(times > a.duration):
        raise ValueError('Observation time outside simulation')
    if np.any(np.diff(times) < 0) or not math.isfinite(max_step+tolerance) or max_step <= 0 or tolerance <= 0:
        raise ValueError('Invalid observation order or integration accuracy')
    breaks = sorted(set([0.0, a.duration] + [d for d in (a.capacity_day, a.allocation_day)
                                               if 0 < d < a.duration]))
    state = np.array([a.initial_n, a.initial_i, a.initial_r, 0.0])
    rows = np.zeros((len(times), 4))
    for left, right in zip(breaks[:-1], breaks[1:]):
        active = replace(a, capacity_gain=a.capacity_gain if left >= a.capacity_day else 0.0,
                          allocation_gain=a.allocation_gain if left >= a.allocation_day else 0.0)
        solution = solve_ivp(lambda day, y: derivative(active, day, y), (left, right), state,
                             dense_output=True, max_step=max_step, rtol=tolerance,
                             atol=tolerance*0.01)
        if not solution.success:
            raise RuntimeError(solution.message)
        selected = (times >= left) & (times <= right)
        rows[selected] = solution.sol(times[selected]).T
        state = solution.y[:, -1]
    total = rows[:, :3].sum(axis=1)
    residual = rows.sum(axis=1)-sum((a.initial_n, a.initial_i, a.initial_r))-np.array([supplied(a,t) for t in times])
    if rows.min() < -tolerance*100 or np.max(np.abs(residual)) > tolerance*100:
        raise ArithmeticError('Mass conservation or nonnegativity failed')
    if math.isfinite(a.capacity_ratio):
        capacity = a.capacity_ratio * rows[:,0] * (1+a.capacity_gain*(times >= a.capacity_day))
        if np.any(rows[:,1] > capacity+tolerance*100):
            raise ArithmeticError('Inulin exceeds the assumed storage capacity')
    return {'day': times, 'N': rows[:,0], 'I': rows[:,1], 'R': rows[:,2], 'L': rows[:,3],
            'dry_mass': total, 'inulin_fraction': np.divide(rows[:,1], total,
             out=np.zeros_like(total), where=total>0), 'supplied': np.array([supplied(a,t) for t in times]),
            'residual': residual}
