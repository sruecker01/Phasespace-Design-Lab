"""Compare declared supply profiles with an external inulin time series.

Fit to digitized NIL group means at 8 and 12 weeks. Keep 24-week means out
of the fit. This retrospective model check uses relative residuals with
equal endpoint weights; it is not a likelihood or a biological validation.
"""
from dataclasses import replace
from itertools import product
from pathlib import Path
import json
import numpy as np
from scipy.optimize import least_squares
from scipy.special import expit, logit
from model import Parameters, simulate
from run_analysis import write_csv

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'output'
raw=json.loads((ROOT/'sources/benninghaus_2020_developmental.json').read_text())['rows']
rows=[r for r in raw if r['genotype']=='NIL']

def value(age,endpoint):
    row=next(r for r in rows if r['age_week']==age and r['endpoint']==endpoint)
    scale=1000 if endpoint=='inulin_concentration' else 1
    return row['mean']/scale,row['digitization_mean_bound_plusminus']/scale

means=np.array([value(age,endpoint)[0] for age in [8,12]
                for endpoint in ['inulin_per_root','inulin_concentration']])
bounds=np.array([value(age,endpoint)[1] for age in [8,12]
                 for endpoint in ['inulin_per_root','inulin_concentration']])

def fit(profile,k,target):
    template=Parameters(budget=5,inulin_share=.6,duration=168,supply_profile=profile,turnover=k)
    def parameters(theta):
        return replace(template,budget=float(np.exp(theta[0])),inulin_share=float(.95*expit(theta[1])))
    def predictions(theta):
        y=simulate(parameters(theta),[56,84],max_step=2,tolerance=1e-8)
        return np.array([y['I'][0],y['inulin_fraction'][0],y['I'][1],y['inulin_fraction'][1]])
    def residual(theta):
        return (predictions(theta)-target)/target
    fitted=least_squares(residual,[np.log(5),logit(.5)],bounds=([np.log(.01),-10],[np.log(100),10]),
                         max_nfev=120,xtol=1e-10,ftol=1e-10,gtol=1e-10)
    params=parameters(fitted.x)
    y=simulate(params,[56,84,168])
    return params,y,float(np.sqrt(np.mean(residual(fitted.x)**2)))

fits=[]
residual_rows=[]
for profile,k in product(['constant','hump','late'],[0,.01,.03]):
    params,y,rmse=fit(profile,k,means)
    label=f'{profile}_k{k}'
    fit_row={'model':label,'profile':profile,'turnover':k,'budget_g_equivalent':params.budget,
             'inulin_share':params.inulin_share,'early_relative_rmse':rmse}
    for j,age in enumerate([8,12,24]):
        for endpoint,key in [('inulin_per_root','I'),('inulin_concentration','inulin_fraction')]:
            observed,bound=value(age,endpoint)
            predicted=float(y[key][j])
            residual_rows.append({'model':label,'age_week':age,'role':'fit' if age<24 else 'held_out_age',
                                 'endpoint':endpoint,'digitized_mean':observed,'digitization_bound_plusminus':bound,
                                 'prediction':predicted,'relative_residual':(predicted-observed)/observed})
    fit_row.update({'held_out_inulin_g':float(y['I'][2]),'held_out_fraction':float(y['inulin_fraction'][2])})
    fits.append(fit_row)
write_csv(OUT/'developmental_fits.csv',fits)
write_csv(OUT/'developmental_residuals.csv',residual_rows)
best=min(fits,key=lambda r:r['early_relative_rmse'])
perturbations=[]
for signs in product([-1,1],repeat=4):
    target=means+np.array(signs)*bounds
    params,y,rmse=fit(best['profile'],best['turnover'],target)
    perturbations.append({'corner':str(signs),'early_relative_rmse':rmse,'budget_g_equivalent':params.budget,
                          'held_out_inulin_g':float(y['I'][2]),'held_out_fraction':float(y['inulin_fraction'][2])})
write_csv(OUT/'digitization_sensitivity.csv',perturbations)
summary={'fit_count':len(fits),'training_days':[56,84],'held_out_day':168,
         'best_early_fit':best,'observed_held_out_inulin_g':value(24,'inulin_per_root')[0],
         'observed_held_out_fraction':value(24,'inulin_concentration')[0],
         'training_graph_uncertainty_corners':len(perturbations),
         'perturbed_prediction_range_g':[min(r['held_out_inulin_g'] for r in perturbations),
                                          max(r['held_out_inulin_g'] for r in perturbations)],
         'assessment':'Inspect early-fit residuals before interpreting held-out errors. Pooling and graph extraction limit precision. No measured dry-root mean is reconstructed from these group means.'}
(OUT/'developmental_summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
