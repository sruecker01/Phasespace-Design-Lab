"""Functional changes from model day zero under the same imported supply budget."""
from dataclasses import replace
from itertools import product
from pathlib import Path
import json
from model import Parameters
from run_analysis import endpoint, write_csv
root=Path(__file__).resolve().parent
out=root/'output'
a=Parameters(**json.loads((out/'baseline_parameters.json').read_text()))
rows=[]
for capacity,allocation,retention in product([0,1],repeat=3):
    params=replace(a,capacity_gain=.25*capacity,allocation_gain=.1*allocation,
                   turnover=a.turnover*(1-.25*retention),capacity_day=0,allocation_day=0)
    row=endpoint(f'capacity{capacity}_allocation{allocation}_retention{retention}',params)
    row.update({'higher_capacity':capacity,'higher_allocation':allocation,'reduced_turnover':retention,
                'intervention_start_day':0})
    rows.append(row)
write_csv(out/'functional_comparison.csv',rows)
base=rows[0]
summary=[]
for r in rows:
    summary.append({'scenario':r['scenario'],'mass_change_percent':100*(r['dry_mass_g_equivalent']/base['dry_mass_g_equivalent']-1),
                    'inulin_change_percent':100*(r['inulin_g_equivalent']/base['inulin_g_equivalent']-1)})
write_csv(out/'functional_changes.csv',summary)
print(json.dumps(summary,indent=2))
