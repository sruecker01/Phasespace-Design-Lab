"""Two-pool root dry-matter model, v0.1.0. Python standard library only.

I = inulin dry mass, N = all other root dry matter (not just structure).
J = constant effective root dry-matter-equivalent input, p = allocation to I.
k = effective mobilization rate; eta = recovered fraction entering N.
    dI/dt = p*J - k*I
    dN/dt = (1-p)*J + eta*k*I
    dL/dt = (1-eta)*k*I
N + I + L = N0 + I0 + J*t. L is net loss from the modelled root pools.
This is process accounting, NOT a validated cellular/signalling/crop model.
"""
from dataclasses import dataclass
import math

VERSION='0.1.0'
@dataclass(frozen=True)
class Parameters:
    J: float
    p: float
    k: float
    eta: float=0.0
    N0: float=0.0
    I0: float=0.0
    def __post_init__(self):
        if not all(math.isfinite(x) for x in (self.J,self.p,self.k,self.eta,self.N0,self.I0)):
            raise ValueError('Parameters must be finite')
        if self.J<0 or self.k<0 or self.N0<0 or self.I0<0 or not 0<=self.p<=1 or not 0<=self.eta<=1:
            raise ValueError('Unphysical parameter value')

def residence(k: float,t: float)->float:
    if k<0 or t<0 or not math.isfinite(k+t):
        raise ValueError('Nonnegative finite rate and time required')
    return t if k==0 else -math.expm1(-k*t)/k

def state(a: Parameters,t: float)->tuple[float,float,float]:
    """Return N,I,L. Analytic solution, with conservation explicit."""
    if t<0 or not math.isfinite(t):raise ValueError('Invalid time')
    I=a.I0*math.exp(-a.k*t)+a.p*a.J*residence(a.k,t)
    mobilized=a.I0+a.p*a.J*t-I
    N=a.N0+(1-a.p)*a.J*t+a.eta*mobilized
    L=(1-a.eta)*mobilized
    return N,I,L

def fit_endpoint(B: float,c: float,T: float,k: float,eta: float=0,N0: float=0,I0: float=0)->Parameters:
    """Match representative B,c exactly conditional on specified k,eta,initials.
    Does not identify parameters, infer plant-level covariance, or validate model.
    """
    if not math.isfinite(B+c+T) or B<=0 or not 0<c<1 or T<=0:
        raise ValueError('Invalid calibration endpoint')
    if k<0 or not 0<=eta<=1 or min(N0,I0)<0:raise ValueError('Invalid assumptions')
    I=B*c;N=B-I
    qI=(I-I0*math.exp(-k*T))/residence(k,T)
    mobilized=I0+qI*T-I
    qN=(N-N0-eta*mobilized)/T
    if qI<0 or qN<0:raise ValueError('Endpoint incompatible with nonnegative inflows')
    J=qN+qI
    if J<=0:raise ValueError('Nonpositive total input')
    return Parameters(J,qI/J,k,eta,N0,I0)

def fit_common_supply(B: float,c: float,T: float,J: float)->Parameters:
    """Illustrative eta=0, zero-initial model with prescribed common supply."""
    qN=B*(1-c)/T;qI=J-qN
    if J<B/T or qI<=0:raise ValueError('Supply cannot support endpoint')
    if math.isclose(J,B/T,abs_tol=1e-14):return fit_endpoint(B,c,T,0)
    target=B*c
    lo,hi=0.,1.
    while qI*residence(hi,T)>target:hi*=2
    for _ in range(100):
        mid=(lo+hi)/2
        if qI*residence(mid,T)>target:lo=mid
        else:hi=mid
    return Parameters(J,qI/J,(lo+hi)/2)

def rk4(a: Parameters,T: float,dt: float=.25)->tuple[float,float,float]:
    """Independent numerical check of the analytic trajectory."""
    if T<0 or dt<=0:raise ValueError('Invalid time/step')
    y=[a.N0,a.I0,0.];t=0.
    def f(v):
        return [(1-a.p)*a.J+a.eta*a.k*v[1],a.p*a.J-a.k*v[1],(1-a.eta)*a.k*v[1]]
    while t<T-1e-12:
        h=min(dt,T-t)
        k1=f(y);k2=f([v+h*q/2 for v,q in zip(y,k1)])
        k3=f([v+h*q/2 for v,q in zip(y,k2)]);k4=f([v+h*q for v,q in zip(y,k3)])
        y=[v+h*(q1+2*q2+2*q3+q4)/6 for v,q1,q2,q3,q4 in zip(y,k1,k2,k3,k4)]
        t+=h
    return tuple(y)

def matrix_rank(rows: list[list[float]],tol: float=1e-7)->int:
    """Small scaled-Jacobian Gaussian elimination; no linear algebra package."""
    a=[r[:] for r in rows]
    if not a:return 0
    rank=0
    for c in range(len(a[0])):
        pivot=max(range(rank,len(a)),key=lambda r:abs(a[r][c]),default=rank)
        if rank>=len(a) or abs(a[pivot][c])<=tol:continue
        a[rank],a[pivot]=a[pivot],a[rank]
        scale=a[rank][c];a[rank]=[v/scale for v in a[rank]]
        for r in range(len(a)):
            if r!=rank:
                scale=a[r][c];a[r]=[u-scale*v for u,v in zip(a[r],a[rank])]
        rank+=1
        if rank==len(a):break
    return rank

def scaled_jacobian(a: Parameters,spec: list[tuple[str,float]])->list[list[float]]:
    """Sensitivity to log J, log p, log k. eta, initial conditions fixed."""
    if min(a.J,a.p,a.k)<=0:raise ValueError('Positive parameters needed for log sensitivity')
    def obs(p):
        out=[]
        for which,t in spec:
            N,I,_=state(p,t)
            out.append({'N':N,'I':I,'B':N+I}[which])
        return out
    base=obs(a);matrix=[[0.]*3 for _ in base];h=1e-5
    from dataclasses import replace
    for j,key in enumerate(['J','p','k']):
        plus=obs(replace(a,**{key:getattr(a,key)*math.exp(h)}))
        minus=obs(replace(a,**{key:getattr(a,key)*math.exp(-h)}))
        for i,(u,v,b) in enumerate(zip(plus,minus,base)):
            matrix[i][j]=(u-v)/(2*h*max(abs(b),1e-12))
    return matrix
