"""Rebuild and reproduce the archived-read analysis from pinned local inputs."""
from pathlib import Path
import hashlib,json,subprocess
ROOT=Path(__file__).resolve().parent
for item in json.loads((ROOT/'metadata'/'download_manifest.json').read_text()):
    path=ROOT/'inputs'/item['filename']
    digest=hashlib.sha256()
    with path.open('rb') as stream:
        while block:=stream.read(1024*1024):digest.update(block)
    if path.stat().st_size!=item['bytes'] or digest.hexdigest()!=item['sha256']:
        raise ValueError('Input version differs from the recorded analysis: '+item['filename'])
(ROOT/'results').mkdir(exist_ok=True)
subprocess.run(['c++','-O3','-std=c++17',str(ROOT/'count_reads.cpp'),'-lz','-o',str(ROOT/'count_reads')],check=True)
subprocess.run(['python3',str(ROOT/'verify_counter.py')],check=True)
subprocess.run([str(ROOT/'count_reads'),'index',str(ROOT/'inputs'/'RubberDandelion_GWHAAAA00000000_CDS.fasta.gz'),str(ROOT/'results')],check=True)
for run in ['SRR17037343','SRR17037341','SRR17037339']:
    subprocess.run([str(ROOT/'count_reads'),'count',str(ROOT/'results'/'markers.tsv'),str(ROOT/'inputs'/(run+'.fastq.gz')),str(ROOT/'results'/run)],check=True)
subprocess.run(['python3',str(ROOT/'inspect_sources.py')],check=True)
subprocess.run(['python3',str(ROOT/'summarize.py')],check=True)
subprocess.run(['python3',str(ROOT/'replay_diagnostic.py')],check=True)
