"""Independently check optimized marker discovery and read classification."""
from pathlib import Path
import csv,random,subprocess,tempfile,gzip,json
ROOT=Path(__file__).resolve().parent
TARGETS=['GWHGAAAA003778','GWHGAAAA042727','GWHGAAAA024456','GWHGAAAA001235']
rc=lambda s:s.translate(str.maketrans('ACGT','TGCA'))[::-1]
random.seed(62347)
def seq(n):return ''.join(random.choices('ACGT',k=n))
def words(s):return {min(s[i:i+21],rc(s[i:i+21])) for i in range(len(s)-20)}
sequences={g:seq(420) for g in TARGETS}
# Include a shared family segment and an isoform of the same gene.
records=[('tx'+str(i),g,s) for i,(g,s) in enumerate(sequences.items())]
records.append(('isoform',TARGETS[0],sequences[TARGETS[0]][40:]))
records.append(('decoy','other_gene',seq(80)+sequences[TARGETS[0]][300:360]+seq(80)))
records.append(('reverse_decoy','another_gene',seq(80)+rc(sequences[TARGETS[1]][300:360])+seq(80)))
with tempfile.TemporaryDirectory() as tmp:
 p=Path(tmp)
 ref=p/'reference.fasta'
 ref.write_text(''.join('>'+i+' Gene='+g+'\n'+s+'\n' for i,g,s in records))
 subprocess.run([str(ROOT/'count_reads'),'index',str(ref),str(p)],check=True)
 actual={g:set() for g in TARGETS}
 with (p/'markers.tsv').open() as f:
  for row in csv.DictReader(f,delimiter='\t'):actual[row['gene']].add(row['word'])
 expected={}
 for g in TARGETS:
  same=set().union(*(words(s) for _,gene,s in records if gene==g))
  other=set().union(*(words(s) for _,gene,s in records if gene!=g))
  expected[g]=same-other
 assert actual==expected,'Marker discovery differs from independent string sets'
 a,b,c,d=[sequences[g] for g in TARGETS]
 # Each tuple gives name, read, expected full assignment, expected first75 assignment, shared flowcell.
 cases=[
 ('forward',a[:100],0,0,True),
 ('reverse',rc(a[:100]),0,0,True),
 ('exact42',a[:42],0,None,True),
 ('too_short41',a[:41],None,None,True),
 ('overlap',a[:22],None,None,True),
 ('repeat_same_word',a[:21]+'N'*40+a[:21],None,None,True),
 ('two_distinct',a[:21]+'N'*40+a[50:71],0,None,True),
 ('two_distinct_in_first75',a[:21]+'N'*10+a[50:71]+'N'*30,0,0,True),
 ('mixed',a[:50]+'N'*5+b[:50],None,0,True),
 ('shared_segment',a[300:360]+'N'*25,None,None,True),
 ('reverse_shared_segment',rc(b[300:360])+'N'*25,None,None,True),
 ('second',b[:100],1,1,True),
 ('third',c[:100],2,2,True),
 ('fourth_other_flow',d[:100],3,3,False),
 ('ambiguous', 'N'*100,None,None,True),
 ]
 with (p/'reads.fastq').open('w') as f:
  for name,s,_,_,shared in cases:
   flow='H772FBGXX' if shared else 'OTHERFLOW'
   f.write(f'@TEST:001:{flow}:1:1:1:{name}\n{s}\n+\n'+('I'*len(s))+'\n')
 subprocess.run([str(ROOT/'count_reads'),'count',str(p/'markers.tsv'),str(p/'reads.fastq'),str(p/'test')],check=True)
 rows=list(csv.DictReader((p/'test.counts.tsv').open(),delimiter='\t'))
 for mode in ['full','first75','shared75']:
  eligible=[r for r in cases if mode=='full' or (len(r[1])>=75 and (mode!='shared75' or r[4]))]
  expected_counts=[sum(r[2 if mode=='full' else 3]==g for r in eligible) for g in range(4)]
  got=[int(row['count']) for row in rows if row['mode']==mode]
  assert got==expected_counts,(mode,got,expected_counts)
  assert all(int(row['denominator'])==len(eligible) for row in rows if row['mode']==mode)
 (p/'broken.fastq').write_text('@bad\nACTG\n+\n')
 bad=subprocess.run([str(ROOT/'count_reads'),'count',str(p/'markers.tsv'),str(p/'broken.fastq'),str(p/'bad')],capture_output=True)
 assert bad.returncode!=0 and b'Malformed' in bad.stderr
result={'marker_set_equivalence':True,'synthetic_read_cases':len(cases),'comparison_modes':3,'malformed_fastq_rejected':True}
(ROOT/'results'/'verification.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
