from pathlib import Path
import csv,json,hashlib
root=Path(__file__).resolve().parent
provenance=list(csv.DictReader((root/'metadata'/'sample_provenance.tsv').open(),delimiter='\t'))
all_rows=[];checks=[];flows=[]
for source in provenance:
 run=source['run'];p=root/'results'
 rows=list(csv.DictReader((p/(run+'.counts.tsv')).open(),delimiter='\t'))
 base_rows=list(csv.DictReader((p/(run+'.bases.tsv')).open(),delimiter='\t'))
 base_count=sum(int(r['count']) for r in base_rows)
 actual=int(rows[0]['denominator'])
 assert actual==int(source['archive_spots'])
 assert base_count==int(source['archive_bases'])
 checks.append(dict(run=run,reads=actual,bases=base_count,spot_total_matches_ENA=True,base_total_matches_ENA=True))
 for row in rows:all_rows.append(dict(pool=source['pool'],run=run,**row))
 for row in csv.DictReader((p/(run+'.flowcells.tsv')).open(),delimiter='\t'):flows.append(dict(run=run,**row))
def write(name,rows):
 with (root/'results'/name).open('w') as f:
  writer=csv.DictWriter(f,fieldnames=list(rows[0]),delimiter='\t',lineterminator='\n');writer.writeheader();writer.writerows(rows)
write('counts.tsv',all_rows);write('flowcells.tsv',flows)
lookup={(r['pool'],r['mode'],r['gene']):r for r in all_rows}
ratios=[]
for mode in ['full','first75','shared75']:
 for gene in ['GWHGAAAA003778','GWHGAAAA042727','GWHGAAAA024456','GWHGAAAA001235']:
  a=lookup[('poolA_RT',mode,gene)]
  for pool in ['poolB_RT','poolC_RT']:
   b=lookup[(pool,mode,gene)]
   for rule,column in [('two_nonoverlapping_markers','count'),('one_marker_sensitivity','one_marker_count')]:
    ar=int(a[column])/int(a['denominator']);br=int(b[column])/int(b['denominator'])
    ratios.append(dict(gene=gene,mode=mode,rule=rule,comparison='A/'+pool[4],A_reads=a[column],other_reads=b[column],A_cpm=ar*1e6,other_cpm=br*1e6,A_to_other_ratio=ar/br if br>0 else 'undefined'))
write('contrasts.tsv',ratios)
(root/'results'/'integrity_checks.json').write_text(json.dumps(checks,indent=2)+'\n')
print(json.dumps(checks))
