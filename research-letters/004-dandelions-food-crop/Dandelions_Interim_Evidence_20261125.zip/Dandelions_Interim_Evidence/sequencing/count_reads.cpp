#include <zlib.h>
#include <algorithm>
#include <array>
#include <cstdint>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <map>
#include <set>
#include <sstream>
#include <stdexcept>
#include <string>
#include <unordered_map>
#include <unordered_set>
#include <vector>

using std::string;
using Word = uint64_t;
constexpr int k = 21;
constexpr Word mask = (Word(1) << 42) - 1;
const std::array<string,4> targets = {"GWHGAAAA003778","GWHGAAAA042727","GWHGAAAA024456","GWHGAAAA001235"};

struct Reader {
    gzFile input;
    explicit Reader(const string& path): input(gzopen(path.c_str(),"rb")) {
        if (!input) throw std::runtime_error("Cannot open " + path);
        gzbuffer(input,1<<20);
    }
    ~Reader() { gzclose(input); }
    bool line(string& result) {
        result.clear();
        char buffer[8192];
        while (gzgets(input,buffer,sizeof buffer)) {
            result += buffer;
            if (!result.empty() && result.back()=='\n') break;
        }
        int error;
        const char* message = gzerror(input,&error);
        if (error!=Z_OK && error!=Z_STREAM_END) throw std::runtime_error(message);
        if (result.empty()) return false;
        if (result.back()=='\n') result.pop_back();
        if (!result.empty() && result.back()=='\r') result.pop_back();
        return true;
    }
};

int base(char c) {
    switch(c) {
        case 'A': case 'a': return 0;
        case 'C': case 'c': return 1;
        case 'G': case 'g': return 2;
        case 'T': case 't': return 3;
        default:return -1;
    }
}

template<class F> void words(const string& sequence,size_t limit,F callback) {
    Word forward=0,reverse=0;
    int length=0;
    for(size_t pos=0;pos<std::min(sequence.size(),limit);++pos) {
        int b=base(sequence[pos]);
        if(b<0) { forward=reverse=0;length=0;continue; }
        forward=((forward<<2)|b)&mask;
        reverse=(reverse>>2)|(Word(3-b)<<40);
        length=std::min(length+1,k);
        if(length==k) callback(std::min(forward,reverse),forward<reverse ? 1 : 2,pos+1-k);
    }
}

string decode(Word w) {
    string s(k,'A');
    for(int i=k-1;i>=0;--i) { s[i]="ACGT"[w&3];w>>=2; }
    return s;
}

struct Record { string id,gene,sequence; };
std::vector<Record> reference(const string& path) {
    Reader input(path);
    std::vector<Record> records;
    std::set<string> ids;
    string line;
    while(input.line(line)) {
        if(line.empty()) continue;
        if(line[0]=='>') {
            std::istringstream header(line.substr(1));
            Record record;
            header>>record.id;
            string field;
            while(header>>field) if(field.rfind("Gene=",0)==0) record.gene=field.substr(5);
            if(record.gene.empty() || !ids.insert(record.id).second) throw std::runtime_error("Bad FASTA header");
            records.push_back(record);
        } else {
            if(records.empty()) throw std::runtime_error("Sequence before header");
            records.back().sequence+=line;
        }
    }
    return records;
}

struct Marker { int gene,strands; bool unique; };
using Markers = std::unordered_map<Word,Marker>;
Markers make_index(const std::vector<Record>& records,const string& output) {
    Markers markers;
    std::array<size_t,4> lengths{},record_counts{},unique_counts{};
    for(const auto& record: records) {
        auto found=std::find(targets.begin(),targets.end(),record.gene);
        if(found==targets.end()) continue;
        int gene=found-targets.begin();
        lengths[gene]+=record.sequence.size(); ++record_counts[gene];
        words(record.sequence,record.sequence.size(),[&](Word w,int strand,size_t){
            auto p=markers.emplace(w,Marker{gene,strand,true}).first;
            if(p->second.gene!=gene) p->second.unique=false;
            else p->second.strands|=strand;
        });
    }
    for(auto c:record_counts) if(c==0) throw std::runtime_error("Target absent");
    std::vector<bool> prescreen(1<<20,false);
    for(const auto& p:markers) prescreen[p.first&((1<<20)-1)]=true;
    for(const auto& record:records) {
        auto found=std::find(targets.begin(),targets.end(),record.gene);
        int gene=found==targets.end() ? -1 : found-targets.begin();
        words(record.sequence,record.sequence.size(),[&](Word w,int,size_t){
            if(!prescreen[w&((1<<20)-1)]) return;
            auto p=markers.find(w);
            if(p!=markers.end() && p->second.gene!=gene) p->second.unique=false;
        });
    }
    for(auto p=markers.begin();p!=markers.end();) {
        if(!p->second.unique) p=markers.erase(p);
        else { ++unique_counts[p->second.gene];++p; }
    }
    std::ofstream out(output+"/markers.tsv"),qc(output+"/reference.tsv");
    out<<"word\tgene\tstrands\n";
    std::vector<Word> ordered;
    for(const auto& p:markers) ordered.push_back(p.first);
    std::sort(ordered.begin(),ordered.end());
    for(Word w:ordered) out<<decode(w)<<'\t'<<targets[markers[w].gene]<<'\t'<<markers[w].strands<<'\n';
    qc<<"gene\ttranscripts\tbases\texclusive_words\ttotal_reference_records\n";
    for(int g=0;g<4;++g) qc<<targets[g]<<'\t'<<record_counts[g]<<'\t'<<lengths[g]<<'\t'<<unique_counts[g]<<'\t'<<records.size()<<'\n';
    return markers;
}

Markers read_index(const string& path) {
    Reader input(path);
    string line;
    input.line(line);
    Markers result;
    while(input.line(line)) {
        std::istringstream row(line);
        string word,gene;int strands;
        row>>word>>gene>>strands;
        auto found=std::find(targets.begin(),targets.end(),gene);
        if(found==targets.end() || word.size()!=k) throw std::runtime_error("Bad index");
        words(word,word.size(),[&](Word w,int,size_t){result.emplace(w,Marker{int(found-targets.begin()),strands,true});});
    }
    return result;
}

struct Hit { Word word;size_t position;int gene,strands; };
struct Totals {
    uint64_t denominator=0,any=0,mixed=0,weak=0;
    std::array<uint64_t,4> counts{},single{};
};
bool count_sequence(const string& sequence,size_t limit,const Markers& markers,const std::vector<bool>& prescreen,Totals& total) {
    ++total.denominator;
    std::vector<Hit> hits;
    int gene=-1;
    bool mixed=false;
    words(sequence,limit,[&](Word w,int strand,size_t position){
        if(!prescreen[w&((1<<20)-1)]) return;
        auto p=markers.find(w);
        if(p==markers.end()) return;
        if(gene!=-1 && p->second.gene!=gene) mixed=true;
        gene=p->second.gene;
        int relative=p->second.strands==3 ? 3 : (p->second.strands==strand ? 1 : 2);
        hits.push_back(Hit{w,position,gene,relative});
    });
    if(hits.empty()) return false;
    ++total.any;
    if(mixed) { ++total.mixed;return true; }
    ++total.single[gene];
    for(size_t i=0;i<hits.size();++i) {
        for(size_t j=i+1;j<hits.size();++j) {
            if(hits[j].position>=hits[i].position+k && hits[j].word!=hits[i].word && (hits[j].strands&hits[i].strands)) {
                ++total.counts[gene];return true;
            }
        }
    }
    ++total.weak;
    return true;
}

void process(const string& index,const string& path,const string& prefix) {
    auto markers=read_index(index);
    std::vector<bool> prescreen(1<<20,false);
    for(auto& p:markers) prescreen[p.first&((1<<20)-1)]=true;
    Reader input(path);
    string header,sequence,plus,quality;
    std::array<Totals,3> total;
    std::map<string,std::pair<uint64_t,uint64_t>> flows;
    std::array<uint64_t,5> bases{};
    gzFile saved=gzopen((prefix+".diagnostic.fastq.gz").c_str(),"wb");
    if(!saved) throw std::runtime_error("Cannot open diagnostic reads");
    while(input.line(header)) {
        if(header.empty() || header[0]!='@' || !input.line(sequence) || !input.line(plus) || plus.empty() || plus[0]!='+' || !input.line(quality) || quality.size()!=sequence.size())
            throw std::runtime_error("Malformed FASTQ after "+std::to_string(total[0].denominator));
        std::vector<string> fields;
        std::istringstream hs(header);string field;
        while(std::getline(hs,field,':')) fields.push_back(field);
        string flow=fields.size()>2 ? fields[2] : "unparsed";
        ++flows[flow].first; flows[flow].second+=sequence.size();
        for(char c:sequence) { int b=base(c);++bases[b<0?4:b]; }
        if(count_sequence(sequence,sequence.size(),markers,prescreen,total[0])) {
            string text=header+'\n'+sequence+'\n'+plus+'\n'+quality+'\n';
            if(gzwrite(saved,text.data(),text.size())!=int(text.size())) throw std::runtime_error("Write diagnostic failed");
        }
        if(sequence.size()>=75) {
            count_sequence(sequence,75,markers,prescreen,total[1]);
            if(flow=="H772FBGXX") count_sequence(sequence,75,markers,prescreen,total[2]);
        }
    }
    if(gzclose(saved)!=Z_OK) throw std::runtime_error("Diagnostic gzip incomplete");
    std::ofstream out(prefix+".counts.tsv"),flowout(prefix+".flowcells.tsv"),baseout(prefix+".bases.tsv");
    out<<"mode\tgene\tcount\tdenominator\tcounts_per_million\tone_marker_count\tany_marker_reads\tmixed_reads\tweak_reads\n";
    const std::array<string,3> modes={"full","first75","shared75"};
    for(size_t m=0;m<3;++m) for(int g=0;g<4;++g) {
        auto& t=total[m];
        out<<modes[m]<<'\t'<<targets[g]<<'\t'<<t.counts[g]<<'\t'<<t.denominator<<'\t'<<std::setprecision(12)<<double(t.counts[g])*1e6/t.denominator<<'\t'<<t.single[g]<<'\t'<<t.any<<'\t'<<t.mixed<<'\t'<<t.weak<<'\n';
    }
    flowout<<"flowcell\treads\tbases\tmean_length\n";
    for(auto& p:flows)flowout<<p.first<<'\t'<<p.second.first<<'\t'<<p.second.second<<'\t'<<std::setprecision(12)<<double(p.second.second)/p.second.first<<'\n';
    baseout<<"base\tcount\n";
    for(int b=0;b<5;++b)baseout<<"ACGTN"[b]<<'\t'<<bases[b]<<'\n';
    std::cout<<path<<" processed "<<total[0].denominator<<" reads\n";
}

int main(int argc,char** argv) {
    try {
        if(argc==4 && string(argv[1])=="index") { make_index(reference(argv[2]),argv[3]);return 0; }
        if(argc==5 && string(argv[1])=="count") { process(argv[2],argv[3],argv[4]);return 0; }
        throw std::runtime_error("Usage: count_reads index REFERENCE OUTPUT_DIR | count INDEX FASTQ OUTPUT_PREFIX");
    } catch(const std::exception& e) { std::cerr<<e.what()<<'\n';return 1; }
}
