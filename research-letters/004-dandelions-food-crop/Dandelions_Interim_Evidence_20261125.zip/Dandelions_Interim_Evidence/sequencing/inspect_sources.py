from pathlib import Path
from xml.etree import ElementTree as E
import csv,json
root=Path(__file__).resolve().parent
metadata=root/'metadata'
runs=E.parse(metadata/'DDBJ_run.xml').getroot()
experiments={r.attrib['accession']:r for r in E.parse(metadata/'DDBJ_experiment.xml').getroot()}
samples={r.attrib['accession']:r for r in E.parse(metadata/'DDBJ_sample.xml').getroot()}
selected={'SRR17037343':4551524,'SRR17037341':6265938,'SRR17037339':6479601}
rows=[]
for run in runs:
 runid=run.attrib['accession']
 if runid not in selected:continue
 expid=run.find('EXPERIMENT_REF').attrib['accession']
 exp=experiments[expid]
 sampleid=exp.find('.//SAMPLE_DESCRIPTOR').attrib['accession']
 sample=samples[sampleid]
 attrs={x.findtext('TAG'):x.findtext('VALUE') for x in sample.findall('.//SAMPLE_ATTRIBUTE')}
 ena=E.parse(metadata/(runid+'_ena.xml')).getroot()
 stats={x.findtext('TAG'):x.findtext('VALUE') for x in ena.findall('.//RUN_ATTRIBUTE')}
 rows.append(dict(run=runid,experiment=expid,sample=sampleid,biosample=sample.findtext('.//EXTERNAL_ID'),pool=sample.attrib['alias'],phenotype=attrs['phenotype'],tissue=attrs['Tissue part'],age=attrs['age'],status=stats['ENA-STATUS'],archive_spots=int(stats['ENA-SPOT-COUNT']),archive_bases=int(stats['ENA-BASE-COUNT']),paper_clean_reads=selected[runid],count_gap=selected[runid]-int(stats['ENA-SPOT-COUNT'])))
rows.sort(key=lambda r:r['pool'])
with (metadata/'sample_provenance.tsv').open('w') as f:
 writer=csv.DictWriter(f,fieldnames=list(rows[0]),delimiter='\t',lineterminator='\n');writer.writeheader();writer.writerows(rows)
print(json.dumps(rows,indent=2))
