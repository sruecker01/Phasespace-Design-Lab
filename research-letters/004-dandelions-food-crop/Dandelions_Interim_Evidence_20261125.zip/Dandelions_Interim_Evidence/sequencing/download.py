"""Retrieve public archived MACE libraries in resumable byte ranges."""
from urllib.request import urlopen, Request
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import json, hashlib, time, re

ROOT=Path(__file__).resolve().parent
FILES={
 'RubberDandelion_GWHAAAA00000000_CDS.fasta.gz': ('https://rubberdandelionomics.com/rubber/download/RubberDandelion_GWHAAAA00000000_CDS.fasta.gz',18335596),
 'SRR17037343.fastq.gz': ('https://ftp.sra.ebi.ac.uk/vol1/fastq/SRR170/043/SRR17037343/SRR17037343.fastq.gz',335822624),
 'SRR17037341.fastq.gz': ('https://ftp.sra.ebi.ac.uk/vol1/fastq/SRR170/041/SRR17037341/SRR17037341.fastq.gz',None),
 'SRR17037339.fastq.gz': ('https://ftp.sra.ebi.ac.uk/vol1/fastq/SRR170/039/SRR17037339/SRR17037339.fastq.gz',None),
}
CHUNK=4*1024*1024

def size(url):
 for attempt in range(4):
  try:
   with urlopen(Request(url, headers={'Range':'bytes=0-1023'}),timeout=25) as r:
    x=r.headers.get('Content-Range')
    if r.status!=206 or not x:raise RuntimeError('Missing range size')
    r.read()
    return int(x.split('/')[-1])
  except Exception:
   if attempt==3:raise

def download_part(args):
 name,url,total,start=args
 end=min(total-1,start+CHUNK-1)
 p=ROOT/'inputs'/(name+'.parts')/str(start)
 p.parent.mkdir(exist_ok=True)
 if p.exists() and p.stat().st_size==end-start+1:return
 for attempt in range(7):
  try:
   with urlopen(Request(url,headers={'Range':f'bytes={start}-{end}'}),timeout=50) as r:
    expected=f'bytes {start}-{end}/{total}'
    if r.status!=206 or r.headers.get('Content-Range')!=expected:
     raise ValueError(f'Unexpected range {r.status}: {r.headers.get("Content-Range")} != {expected}')
    data=r.read()
    if len(data)!=end-start+1:raise ValueError('Truncated response')
   p.write_bytes(data)
   return
  except Exception as e:
   if attempt==6:raise
   time.sleep(min(4,attempt))

if __name__=='__main__':
 prior=ROOT/'metadata'/'download_manifest.json'
 pinned={r['filename']:r for r in json.loads(prior.read_text())} if prior.exists() else {}
 manifest=[]
 tasks=[]
 for name,(url,total) in FILES.items():
  total=total or size(url)
  print(name,total,flush=True)
  manifest.append({'filename':name,'url':url,'bytes':total})
  tasks.extend((name,url,total,i) for i in range(0,total,CHUNK))
 (ROOT/'metadata'/'download_sources.json').write_text(json.dumps(manifest,indent=2)+'\n')
 # Interleave files so that all libraries make progress.
 tasks.sort(key=lambda a:(a[3],a[0]))
 with ThreadPoolExecutor(max_workers=10) as pool:
  for i,_ in enumerate(pool.map(download_part,tasks),1):
   if i%20==0: print('completed range',i,'/',len(tasks),flush=True)
 for item in manifest:
  p=ROOT/'inputs'/item['filename']
  with p.with_suffix('.partial').open('wb') as out:
   for start in range(0,item['bytes'],CHUNK):out.write((ROOT/'inputs'/(item['filename']+'.parts')/str(start)).read_bytes())
  p.with_suffix('.partial').replace(p)
  h=hashlib.sha256(); md5=hashlib.md5()
  with p.open('rb') as f:
   while data:=f.read(1024*1024):h.update(data);md5.update(data)
  item['sha256']=h.hexdigest();item['md5']=md5.hexdigest()
  if 'CDS' in item['filename']:assert item['sha256']=='5e809f96f270e1f6aa75bb17a981fff6e7957a902653d97c2f506243e72e1570'
  expected=pinned.get(item['filename'])
  if expected and (item['bytes']!=expected['bytes'] or item['sha256']!=expected['sha256']):
   raise ValueError('Retrieved version differs from recorded source: '+item['filename'])
  print('Installed',item['filename'],flush=True)
 (ROOT/'metadata'/'download_manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
