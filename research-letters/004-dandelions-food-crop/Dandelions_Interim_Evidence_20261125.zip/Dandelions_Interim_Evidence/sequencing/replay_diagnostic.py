"""Replay every retained diagnostic read with independent Python string matching."""
from pathlib import Path
import csv,gzip,json
ROOT=Path(__file__).resolve().parent
RESULTS=ROOT/'results'
rc=lambda s:s.translate(str.maketrans('ACGT','TGCA'))[::-1]
markers={}
for row in csv.DictReader((RESULTS/'markers.tsv').open(),delimiter='\t'):
 markers[row['word']]=(row['gene'],int(row['strands']))
def classify(s):
 matches=[]
 for pos in range(len(s)-20):
  word=s[pos:pos+21].upper()
  if set(word)-set('ACGT'):continue
  reverse=rc(word); canonical=min(word,reverse)
  if canonical not in markers:continue
  gene,strands=markers[canonical]
  direction=1 if word<reverse else 2
  relative=3 if strands==3 else (1 if direction==strands else 2)
  matches.append((pos,canonical,gene,relative))
 genes={r[2] for r in matches}
 if len(genes)!=1:return None
 for i,one in enumerate(matches):
  for two in matches[i+1:]:
   if two[0]-one[0]>=21 and one[1]!=two[1] and one[3]&two[3]:return one[2]
 return None
report=[]
for sample in ['SRR17037343','SRR17037341','SRR17037339']:
 infile=RESULTS/(sample+'.diagnostic.fastq.gz')
 if not infile.exists():continue
 observed={}
 reads=0
 with gzip.open(infile,'rt') as stream:
  for h in stream:
   seq=next(stream).strip();plus=next(stream);qual=next(stream).strip()
   assert h.startswith('@') and plus.startswith('+') and len(seq)==len(qual)
   reads+=1
   for mode in ['full','first75','shared75']:
    if mode!='full' and len(seq)<75:continue
    if mode=='shared75' and ':H772FBGXX:' not in h:continue
    gene=classify(seq if mode=='full' else seq[:75])
    if gene is not None:observed[(mode,gene)]=observed.get((mode,gene),0)+1
 for row in csv.DictReader((RESULTS/(sample+'.counts.tsv')).open(),delimiter='\t'):
  assert observed.get((row['mode'],row['gene']),0)==int(row['count']),row
  if row['mode']=='full':assert reads==int(row['any_marker_reads'])
 report.append({'run':sample,'diagnostic_read_records':reads,'all_assignment_counts_reproduced':True})
(RESULTS/'independent_replay.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
