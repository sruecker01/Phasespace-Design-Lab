"""Independent compatibility and conservation review for the integrated extension."""
from pathlib import Path
import hashlib
import importlib.util
import itertools
import json
import sys
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'model'))
import model
import legacy_model

source = ROOT / 'model' / 'model.py'
source_digest = hashlib.sha256(source.read_bytes()).hexdigest()
max_compatibility_error = 0.0
compatibility_cases = 0
for turnover, recovery, seeded in itertools.product([0, 0.001, 0.05], [0, 0.5, 1], [False, True]):
    n0, i0, r0 = (0.15, 0.25, 0.2) if seeded else (0, 0, 0)
    p = model.Parameters(budget=3.36, inulin_share=0.65, turnover=turnover,
        recovery=recovery, competing_share=0.1, competing_retention=1,
        capacity_ratio=float('inf'), supply_profile='constant',
        initial_n=n0, initial_i=i0, initial_r=r0)
    t = np.array([0., 0.5, 1., 28., 42., 84.])
    result = model.simulate(p, times=t, max_step=.25, tolerance=1e-10)
    old = legacy_model.Parameters(J=0.04, p=.65, k=turnover, eta=recovery,
        N0=n0+r0, I0=i0)
    expected = np.array([legacy_model.state(old, day) for day in t])
    actual = np.column_stack([result['N']+result['R'], result['I'], result['L']])
    error = float(np.max(np.abs(actual-expected)))
    assert error < 1e-8, error
    max_compatibility_error = max(max_compatibility_error, error)
    compatibility_cases += 1

max_fixed_budget_error = 0.0
fixed_budget_cases = 0
for profile, capacity, share, turnover in itertools.product(
        ['constant','early','late','hump'], [0.75, 3., float('inf')], [0., .6], [0., .05]):
    p = model.Parameters(budget=3.36, inulin_share=share, turnover=turnover,
        recovery=1., competing_retention=1., capacity_ratio=capacity,
        supply_profile=profile, initial_n=.01)
    result=model.simulate(p)
    error=float(np.max(np.abs(result['dry_mass']-.01-result['supplied'])))
    assert error < 1e-7, error
    max_fixed_budget_error=max(max_fixed_budget_error,error)
    fixed_budget_cases+=1

p=model.Parameters(budget=3.36, inulin_share=.7, turnover=.02,
    recovery=.4, capacity_ratio=1.5, capacity_gain=.5, capacity_day=28.,
    allocation_gain=.2, allocation_day=56.)
series=[model.simulate(p,max_step=step,tolerance=1e-10) for step in [1.,.5,.125]]
convergence_error=max(float(np.max(np.abs(a[key]-series[-1][key])))
    for a in series[:-1] for key in ['N','I','R','L'])
assert convergence_error < 1e-6, convergence_error
capacity=p.capacity_ratio*np.where(series[-1]['day']>=p.capacity_day,1+p.capacity_gain,1)*series[-1]['N']
capacity_excess=float(np.max(series[-1]['I']-capacity))
assert capacity_excess < 1e-7, capacity_excess
assert hashlib.sha256(source.read_bytes()).hexdigest()==source_digest, 'Source changed during verification'
receipt=dict(source_sha256=source_digest, compatibility_cases=compatibility_cases,
             maximum_legacy_compatibility_error_g=max_compatibility_error,
             fixed_budget_lossless_cases=fixed_budget_cases,
             maximum_lossless_mass_error_g=max_fixed_budget_error,
             step_sizes_days=[1.,.5,.125], maximum_convergence_difference_g=convergence_error,
             maximum_capacity_excess_g=capacity_excess, status='PASS')
(ROOT/'review'/'integrated_review_receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2))
