DANDELIONS INTERIM RESEARCH LETTER — SUPPORTING CALCULATIONS
25 November 2026 · Phasespace Design Lab

This compact companion supports the six-page interim letter. It preserves the
executed study's numerical outputs, model code, diagnostic sequence-count evidence,
retrieved archive metadata, digitized observations and execution summaries.

The underlying integrated study was completed on 24 November 2026 (America/Bogota).
Report preparation on 25 November verified its 88 manifest entries and independently
recomputed eight functional comparisons, 36 CPM rows and 48 sequence contrasts.
The underlying simulations and full sequencing analysis were not rerun to prepare
the letter. Existing execution and independent-review receipts are retained.

EVIDENCE CLASSES
1. Published biological experiments: attributed to the primary papers in the letter.
2. Archive reanalysis: conditional observational findings from the retrieved files.
   The ENA records are SUPPRESSED; correspondence with the paper's cleaned counts
   remains unresolved. Sparse target counts and one pooled library per morphotype
   do not provide biological replication or a causal intervention effect.
3. Functional model outputs: hypothetical changes under a fixed effective input
   budget. No measured gene-to-parameter mapping or whole-plant validation exists.
4. Developmental challenge: all nine tested cases fit early observations poorly.
   The later discrepancy is not a prediction from a successfully calibrated model.
5. MeOSR: source acquired and documentary registration completed; compilation,
   native execution, publication reproduction and dandelion calibration not performed.

FILES AND REPRODUCTION
model/ contains the numerical model, analysis scripts, inputs and complete stored
output tables. The original pinned dependencies are in requirements.txt. From model/,
run run_analysis.py, then retention_comparison.py, then developmental_challenge.py
to repeat those numerical analyses. This package does not claim that these scripts
were rerun during report preparation.

sequencing/results/ contains counts, contrasts, markers and all 798 diagnostic reads.
The full 14,498,640-read FASTQ collection and the 46,734-record CDS reference are
excluded to keep this download compact. The preserved metadata gives original
locations, byte counts and digests. Those additional inputs are needed for a full
sequencing replay; this download alone is not a complete raw-data reproduction.
Archived endpoints may have changed or become unavailable.

Original article XML/PDF files, operational parcel payloads, and the MeOSR source
tarball are also excluded. Sources remain identified by DOI, repository revision,
and hashes. MEOSR_STATUS.json retains the input-manifest mismatch as well as the
verified returned outputs. Successful transport and registration are not model
execution or biological validation.

The original model/make_report.py is retained as historical code; its original
report asset layout is not reproduced by this compact download. The current letter
is rebuilt by source/build_report.py in the separate website package.

No improved plant, reproductive outcome, food suitability or ecological result has
been demonstrated by this project. Website publication is not an executed action.
